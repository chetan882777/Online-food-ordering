package com.example.github.di.main;



import dagger.Module;

@Module
public class MainModule {


}
